# Secret Old Man
This monstrosity is a Chrome extension that hides a tiny little picture of an old man somewhere on every website you visit.
Find him and click on him before it's too late!

## Installation
Because this is not yet on the Chrome store, the only way to install Secret Old Man is manually. Just follow these steps:
* Clone this repo
* Go to `chrome://extensions`, and make sure that the developer mode toggle is active
* Click `Load unpacked`, and select the directory of this repo
<br>
You'll be searching for old men in no time!
